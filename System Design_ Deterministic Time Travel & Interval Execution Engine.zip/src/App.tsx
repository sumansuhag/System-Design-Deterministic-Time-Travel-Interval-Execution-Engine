import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { EnvironmentComparison } from './components/EnvironmentComparison';
import { IndexSimulator } from './components/IndexSimulator';
import { ExecutionPlan } from './components/ExecutionPlan';
import { Copy, Database } from 'lucide-react';
import { environments, prodPlan, nonProdPlan, simulatedPlan } from './utils/mockData';
import { QueryPlan } from './types';

function App() {
  const [activePlan, setActivePlan] = useState<'prod' | 'nonprod' | 'simulated'>('prod');
  const [isTransferring, setIsTransferring] = useState(false);

  const handleSimulate = (columns: string) => {
    setActivePlan('simulated');
  };

  const handleTransferRTS = () => {
    setIsTransferring(true);
    setTimeout(() => {
      setIsTransferring(false);
      // In a real app, this would trigger the backend process
      alert('RTS Copy process initiated. Check system logs for progress.');
    }, 2000);
  };

  const getPlan = (): QueryPlan[] => {
    switch (activePlan) {
      case 'prod': return prodPlan;
      case 'nonprod': return nonProdPlan;
      case 'simulated': return simulatedPlan;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Db2 Performance Workbench</h1>
              <p className="text-sm text-slate-500">Index Analysis & RTS Management</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Environment Stats */}
        <section>
          <h2 className="text-lg font-semibold text-slate-800 mb-4">Environment Comparison</h2>
          <EnvironmentComparison environments={environments} />
        </section>

        {/* Main Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Plans */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-800">Execution Plans</h2>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant={activePlan === 'prod' ? 'default' : 'outline'}
                  onClick={() => setActivePlan('prod')}
                >
                  Prod (Actual)
                </Button>
                <Button 
                  size="sm" 
                  variant={activePlan === 'nonprod' ? 'default' : 'outline'}
                  onClick={() => setActivePlan('nonprod')}
                >
                  Non-Prod (Misleading)
                </Button>
                {activePlan === 'simulated' && (
                  <Button 
                    size="sm" 
                    variant="default"
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Simulated
                  </Button>
                )}
              </div>
            </div>

            <ExecutionPlan 
              title={activePlan === 'prod' ? 'Current Production Plan' : activePlan === 'nonprod' ? 'Non-Production Plan' : 'Simulated Plan (With New Index)'} 
              plan={getPlan()} 
              highlight={activePlan === 'simulated'}
            />

            {/* RTS Transfer Action */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Statistics Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Copy className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-slate-800">Copy RTS from Production</h3>
                    <p className="text-sm text-slate-500 mt-1 mb-3">
                      Transfer Real-Time Statistics to Non-Prod to enable accurate EXPLAIN planning without the full data volume.
                    </p>
                    <Button 
                      onClick={handleTransferRTS}
                      disabled={isTransferring}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      {isTransferring ? 'Transferring...' : 'Initiate RTS Copy'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Simulator */}
          <div>
            <IndexSimulator 
              currentPlan={prodPlan} 
              onSimulate={handleSimulate} 
            />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;