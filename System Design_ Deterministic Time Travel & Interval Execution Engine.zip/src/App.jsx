import { useState } from 'react';
import { createEmptyMacro } from './utils/macroHelpers';
import { MacroList } from './components/MacroList';
import { MacroEditor } from './components/MacroEditor';
import { MacroPlayer } from './components/MacroPlayer';
import { Button } from './components/ui/button';
import { Plus, Home } from 'lucide-react';

function App() {
  const [macros, setMacros] = useState([]);
  const [view, setView] = useState('list');
  const [selectedMacro, setSelectedMacro] = useState(null);
  const [editingMacro, setEditingMacro] = useState(null);

  const handleCreateMacro = () => {
    const newMacro = createEmptyMacro();
    setEditingMacro(newMacro);
    setView('editor');
  };

  const handleEditMacro = (id) => {
    const macro = macros.find(m => m.id === id);
    if (macro) {
      setEditingMacro(macro);
      setView('editor');
    }
  };

  const handleSaveMacro = (macro) => {
    const existingIndex = macros.findIndex(m => m.id === macro.id);
    if (existingIndex >= 0) {
      const updated = [...macros];
      updated[existingIndex] = macro;
      setMacros(updated);
    } else {
      setMacros([...macros, macro]);
    }
    setEditingMacro(null);
    setView('list');
  };

  const handleDeleteMacro = (id) => {
    setMacros(macros.filter(m => m.id !== id));
  };

  const handleRunMacro = (id) => {
    const macro = macros.find(m => m.id === id);
    if (macro) {
      setSelectedMacro(macro);
      setView('player');
    }
  };

  const handleCancelEdit = () => {
    setEditingMacro(null);
    setView('list');
  };

  const handleClosePlayer = () => {
    setSelectedMacro(null);
    setView('list');
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-3xl">⚡</div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Macro Manager</h1>
              <p className="text-sm text-slate-500">Automate your workflows</p>
            </div>
          </div>
          {view !== 'list' && (
            <Button variant="ghost" onClick={() => setView('list')}>
              <Home className="w-4 h-4 mr-2" />
              Back to List
            </Button>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {view === 'list' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">My Macros</h2>
                <p className="text-slate-500">Manage and execute your automation scripts</p>
              </div>
              <Button onClick={handleCreateMacro} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                New Macro
              </Button>
            </div>
            <MacroList
              macros={macros}
              onRun={handleRunMacro}
              onDelete={handleDeleteMacro}
              onEdit={handleEditMacro}
            />
          </div>
        )}

        {view === 'editor' && editingMacro && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">
                {macros.find(m => m.id === editingMacro.id) ? 'Edit Macro' : 'Create Macro'}
              </h2>
              <p className="text-slate-500">Define your automation sequence</p>
            </div>
            <MacroEditor
              macro={editingMacro}
              onSave={handleSaveMacro}
              onCancel={handleCancelEdit}
            />
          </div>
        )}

        {view === 'player' && selectedMacro && (
          <div className="max-w-2xl mx-auto">
            <MacroPlayer macro={selectedMacro} onClose={handleClosePlayer} />
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-6xl mx-auto px-4 py-4 text-center text-sm text-slate-500">
          Macro Manager • Build automation sequences with ease
        </div>
      </footer>
    </div>
  );
}

export default App;