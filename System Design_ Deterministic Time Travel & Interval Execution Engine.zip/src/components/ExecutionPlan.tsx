import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ArrowRight, ScanLine, FileSearch } from 'lucide-react';
import { QueryPlan } from '../types';

interface ExecutionPlanProps {
  title: string;
  plan: QueryPlan[];
  highlight?: boolean;
}

export function ExecutionPlan({ title, plan, highlight }: ExecutionPlanProps) {
  const getIcon = (operation: QueryPlan['operation']) => {
    switch (operation) {
      case 'TABLE SCAN': return <ScanLine className="w-5 h-5 text-red-500" />;
      case 'INDEX SCAN': return <FileSearch className="w-5 h-5 text-blue-500" />;
      case 'FETCH': return <ArrowRight className="w-5 h-5 text-slate-500" />;
    }
  };

  const getOperationColor = (operation: QueryPlan['operation']) => {
    switch (operation) {
      case 'TABLE SCAN': return 'bg-red-50 border-red-200';
      case 'INDEX SCAN': return 'bg-blue-50 border-blue-200';
      case 'FETCH': return 'bg-slate-50 border-slate-200';
    }
  };

  const totalCost = plan.reduce((sum, step) => sum + step.cost, 0);

  return (
    <Card className={highlight ? 'border-2 border-blue-300' : ''}>
      <CardHeader className="bg-slate-50 pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">{title}</CardTitle>
          <span className="text-sm font-semibold text-slate-600">Cost: {totalCost.toLocaleString()}</span>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="space-y-3">
          {plan.map((step, idx) => (
            <div key={idx} className={`flex items-center gap-3 p-3 rounded-lg border ${getOperationColor(step.operation)}`}>
              {getIcon(step.operation)}
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-800">{step.operation}</span>
                  {step.operation === 'TABLE SCAN' && (
                    <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">Warning</span>
                  )}
                </div>
                {step.filter && (
                  <p className="text-xs text-slate-500 font-mono mt-1">{step.filter}</p>
                )}
                <p className="text-xs text-slate-400 mt-1">
                  Cardinality: {step.cardinality.toLocaleString()}
                </p>
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-slate-700">{step.cost}</div>
                <div className="text-xs text-slate-400">Timerons</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}