import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { Zap, TrendingDown, Play } from 'lucide-react';
import { QueryPlan } from '../types';

interface IndexSimulatorProps {
  currentPlan: QueryPlan[];
  onSimulate: (columns: string) => void;
}

export function IndexSimulator({ currentPlan, onSimulate }: IndexSimulatorProps) {
  const [indexColumns, setIndexColumns] = useState('STATUS, CREATED_DATE');
  const [isSimulating, setIsSimulating] = useState(false);
  const [result, setResult] = useState<{ newCost: number; reduction: number } | null>(null);

  const currentCost = currentPlan.reduce((sum, step) => sum + step.cost, 0);

  const handleSimulate = () => {
    setIsSimulating(true);
    setResult(null);
    
    // Simulate calculation delay
    setTimeout(() => {
      const newCost = 420; // Mock simulated cost
      const reduction = ((currentCost - newCost) / currentCost) * 100;
      setResult({ newCost, reduction });
      setIsSimulating(false);
      onSimulate(indexColumns);
    }, 1500);
  };

  return (
    <Card className="border-2 border-indigo-100">
      <CardHeader className="bg-indigo-50">
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-indigo-600" />
          What-If Index Simulator
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6 space-y-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="columns">Proposed Index Columns</Label>
            <Input
              id="columns"
              value={indexColumns}
              onChange={(e) => setIndexColumns(e.target.value)}
              placeholder="e.g., STATUS, CREATED_DATE"
              className="font-mono mt-1"
            />
            <p className="text-xs text-slate-500 mt-1">
              Define the key order to address the cardinality issue.
            </p>
          </div>

          <Button 
            onClick={handleSimulate} 
            disabled={isSimulating}
            className="w-full bg-indigo-600 hover:bg-indigo-700"
          >
            {isSimulating ? (
              <>Simulating...</>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Simulation
              </>
            )}
          </Button>
        </div>

        {result && (
          <div className="space-y-4 pt-4 border-t">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Current Cost (Prod)</span>
              <span className="text-lg font-bold text-slate-800">{currentCost.toLocaleString()}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Estimated Cost (New Index)</span>
              <span className="text-lg font-bold text-green-600">{result.newCost.toLocaleString()}</span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1 text-green-700 font-medium">
                  <TrendingDown className="w-4 h-4" />
                  Cost Reduction
                </span>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                  {result.reduction.toFixed(1)}%
                </Badge>
              </div>
              <Progress value={result.reduction} className="h-2" />
            </div>

            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                <strong>Recommendation:</strong> Create index on ({indexColumns}) to eliminate Table Scan.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}