import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Plus, Trash2, ArrowUp, ArrowDown, Save, X } from 'lucide-react';
import { createCommand, getCommandIcon } from '../utils/macroHelpers';

export function MacroEditor({ macro, onSave, onCancel }) {
  const [name, setName] = useState(macro.name);
  const [description, setDescription] = useState(macro.description);
  const [commands, setCommands] = useState(macro.commands);

  const addCommand = (type) => {
    setCommands([...commands, createCommand(type)]);
  };

  const updateCommand = (id, updates) => {
    setCommands(commands.map(cmd => 
      cmd.id === id ? { ...cmd, ...updates } : cmd
    ));
  };

  const deleteCommand = (id) => {
    setCommands(commands.filter(cmd => cmd.id !== id));
  };

  const moveCommand = (index, direction) => {
    const newCommands = [...commands];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex >= 0 && newIndex < newCommands.length) {
      [newCommands[index], newCommands[newIndex]] = [newCommands[newIndex], newCommands[index]];
      setCommands(newCommands);
    }
  };

  const handleSave = () => {
    onSave({
      ...macro,
      name,
      description,
      commands,
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Macro Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter macro name"
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what this macro does"
              rows={2}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Commands</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => addCommand('text')}>
              <Plus className="w-4 h-4 mr-1" />
              Text
            </Button>
            <Button size="sm" variant="outline" onClick={() => addCommand('keypress')}>
              <Plus className="w-4 h-4 mr-1" />
              Key Press
            </Button>
            <Button size="sm" variant="outline" onClick={() => addCommand('click')}>
              <Plus className="w-4 h-4 mr-1" />
              Click
            </Button>
            <Button size="sm" variant="outline" onClick={() => addCommand('delay')}>
              <Plus className="w-4 h-4 mr-1" />
              Delay
            </Button>
          </div>

          <div className="space-y-3">
            {commands.map((cmd, index) => (
              <div key={cmd.id} className="border rounded-lg p-4 bg-slate-50">
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{getCommandIcon(cmd.type)}</div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-600 capitalize">{cmd.type}</span>
                      <span className="text-xs text-slate-400">#{index + 1}</span>
                    </div>
                    
                    {cmd.type === 'delay' ? (
                      <div>
                        <Label>Duration (ms)</Label>
                        <Input
                          type="number"
                          value={cmd.duration || 1000}
                          onChange={(e) => updateCommand(cmd.id, { duration: parseInt(e.target.value) })}
                          className="w-32"
                        />
                      </div>
                    ) : (
                      <div>
                        <Label>Value</Label>
                        <Input
                          value={cmd.value}
                          onChange={(e) => updateCommand(cmd.id, { value: e.target.value })}
                          placeholder={cmd.type === 'click' ? 'element selector' : 'enter value'}
                        />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-col gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => moveCommand(index, 'up')}
                      disabled={index === 0}
                    >
                      <ArrowUp className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => moveCommand(index, 'down')}
                      disabled={index === commands.length - 1}
                    >
                      <ArrowDown className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => deleteCommand(cmd.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3 justify-end">
        <Button variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" />
          Save Macro
        </Button>
      </div>
    </div>
  );
}