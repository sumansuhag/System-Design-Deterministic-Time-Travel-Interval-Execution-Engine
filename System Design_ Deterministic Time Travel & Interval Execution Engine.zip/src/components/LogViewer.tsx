import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { AlertOctagon, AlertTriangle, Info } from 'lucide-react';
import { LogEntry } from '../types';

interface LogViewerProps {
  logs: LogEntry[];
}

export function LogViewer({ logs }: LogViewerProps) {
  const getIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'error': return <AlertOctagon className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'info': return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getBgColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'error': return 'bg-red-50 border-red-100';
      case 'warning': return 'bg-amber-50 border-amber-100';
      case 'info': return 'bg-blue-50 border-blue-100';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Logs</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 font-mono text-sm max-h-96 overflow-y-auto">
          {logs.map((log) => (
            <div 
              key={log.id} 
              className={`flex gap-3 p-3 rounded border ${getBgColor(log.level)}`}
            >
              <span className="text-slate-400 shrink-0">
                {log.timestamp.toLocaleTimeString()}
              </span>
              <div className="flex items-start gap-2 flex-1">
                {getIcon(log.level)}
                <span className={log.level === 'error' ? 'text-red-800' : 'text-slate-700'}>
                  {log.message}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}