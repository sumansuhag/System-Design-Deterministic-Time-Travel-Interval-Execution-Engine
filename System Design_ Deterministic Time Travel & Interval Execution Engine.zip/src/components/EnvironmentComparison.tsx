import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Database, Clock, AlertTriangle } from 'lucide-react';
import { Environment } from '../types';

interface EnvironmentComparisonProps {
  environments: Environment[];
}

export function EnvironmentComparison({ environments }: EnvironmentComparisonProps) {
  const formatNumber = (num: number) => {
    if (num >= 1000000000) return `${(num / 1000000000).toFixed(1)}B`;
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const getStatusColor = (status: Environment['rtsStatus']) => {
    switch (status) {
      case 'current': return 'bg-green-100 text-green-700 border-green-200';
      case 'stale': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'missing': return 'bg-red-100 text-red-700 border-red-200';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {environments.map((env) => (
        <Card key={env.name} className={`border-2 ${env.type === 'production' ? 'border-blue-200' : 'border-slate-200'}`}>
          <CardHeader className="bg-slate-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Database className={`w-5 h-5 ${env.type === 'production' ? 'text-blue-600' : 'text-slate-500'}`} />
                {env.name}
              </CardTitle>
              <Badge className={getStatusColor(env.rtsStatus)} variant="outline">
                RTS: {env.rtsStatus.toUpperCase()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div>
              <p className="text-sm text-slate-500 mb-1">Row Count</p>
              <p className="text-3xl font-bold text-slate-800">{formatNumber(env.rowCount)}</p>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Clock className="w-4 h-4" />
              <span>Last Updated: {env.lastUpdated.toLocaleDateString()} {env.lastUpdated.toLocaleTimeString()}</span>
            </div>

            {env.type === 'non-production' && env.rtsStatus === 'stale' && (
              <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5" />
                <p className="text-sm text-amber-800">
                  Insufficient data volume for accurate EXPLAIN. Consider copying RTS from PROD.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}