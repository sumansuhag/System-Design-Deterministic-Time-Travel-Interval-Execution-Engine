import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Play, Pause, Square, CheckCircle, XCircle } from 'lucide-react';
import { getCommandIcon } from '../utils/macroHelpers';

export function MacroPlayer({ macro, onClose }) {
  const [currentCommandIndex, setCurrentCommandIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!macro || !isRunning || isPaused) return;

    if (currentCommandIndex >= macro.commands.length) {
      setCompleted(true);
      setIsRunning(false);
      return;
    }

    const command = macro.commands[currentCommandIndex];
    const delay = command.type === 'delay' ? (command.duration || 1000) : 500;

    const timer = setTimeout(() => {
      setCurrentCommandIndex(prev => prev + 1);
    }, delay);

    return () => clearTimeout(timer);
  }, [macro, isRunning, isPaused, currentCommandIndex]);

  const handleStart = () => {
    if (!macro) return;
    setCurrentCommandIndex(0);
    setCompleted(false);
    setError(null);
    setIsRunning(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
    setCurrentCommandIndex(0);
  };

  if (!macro) return null;

  const progress = macro.commands.length > 0 
    ? ((currentCommandIndex / macro.commands.length) * 100).toFixed(0)
    : 0;

  return (
    <Card className="border-2 border-blue-200">
      <CardHeader className="bg-blue-50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            {isRunning && !isPaused && <span className="animate-pulse">🔄</span>}
            Running: {macro.name}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ✕
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm text-slate-600 mb-2">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {isRunning && !completed && macro.commands[currentCommandIndex] && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <span className="text-2xl animate-bounce">
                  {getCommandIcon(macro.commands[currentCommandIndex].type)}
                </span>
                <div>
                  <div className="text-sm font-medium text-amber-800">
                    Executing: {macro.commands[currentCommandIndex].type}
                  </div>
                  <div className="text-sm text-amber-600">
                    {macro.commands[currentCommandIndex].value || 
                     (macro.commands[currentCommandIndex].duration ? 
                      `${macro.commands[currentCommandIndex].duration}ms` : '')}
                  </div>
                </div>
              </div>
            </div>
          )}

          {completed && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <div>
                <div className="font-medium text-green-800">Macro Completed!</div>
                <div className="text-sm text-green-600">
                  {macro.commands.length} commands executed successfully
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
              <XCircle className="w-6 h-6 text-red-600" />
              <div>
                <div className="font-medium text-red-800">Error</div>
                <div className="text-sm text-red-600">{error}</div>
              </div>
            </div>
          )}

          <div className="flex gap-2 justify-center">
            {!isRunning ? (
              <Button onClick={handleStart} className="w-32">
                <Play className="w-4 h-4 mr-2" />
                Start
              </Button>
            ) : (
              <>
                <Button onClick={handlePause} variant="outline" className="w-32">
                  {isPaused ? (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Resume
                    </>
                  ) : (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Pause
                    </>
                  )}
                </Button>
                <Button onClick={handleStop} variant="outline" className="w-32">
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}