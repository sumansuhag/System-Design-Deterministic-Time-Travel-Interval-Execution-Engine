import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { CheckCircle, AlertTriangle, XCircle, Activity } from 'lucide-react';
import { SystemMetric } from '../types';

interface StatusCardProps {
  metric: SystemMetric;
}

export function StatusCard({ metric }: StatusCardProps) {
  const getStatusIcon = () => {
    switch (metric.status) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'critical':
        return <XCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getStatusColor = () => {
    switch (metric.status) {
      case 'healthy': return 'border-green-200 bg-green-50';
      case 'warning': return 'border-amber-200 bg-amber-50';
      case 'critical': return 'border-red-200 bg-red-50';
    }
  };

  return (
    <Card className={`border-2 ${getStatusColor()}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-slate-400" />
            <div>
              <p className="text-sm font-medium text-slate-600">{metric.name}</p>
              <p className="text-lg font-bold text-slate-800">{metric.value}</p>
            </div>
          </div>
          {getStatusIcon()}
        </div>
      </CardContent>
    </Card>
  );
}