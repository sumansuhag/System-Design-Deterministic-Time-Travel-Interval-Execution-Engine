import { Macro } from '../types/macro';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Play, Trash2, Edit } from 'lucide-react';

interface MacroListProps {
  macros: Macro[];
  onRun: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
}

export function MacroList({ macros, onRun, onDelete, onEdit }: MacroListProps) {
  if (macros.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📋</div>
        <h3 className="text-xl font-semibold text-slate-700 mb-2">No Macros Yet</h3>
        <p className="text-slate-500">Create your first macro to get started</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {macros.map((macro) => (
        <Card key={macro.id} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-lg">{macro.name}</CardTitle>
                <CardDescription className="mt-1">
                  {macro.description || 'No description'}
                </CardDescription>
              </div>
              <div className={`w-3 h-3 rounded-full ${
                macro.status === 'running' ? 'bg-green-500 animate-pulse' :
                macro.status === 'completed' ? 'bg-blue-500' :
                macro.status === 'error' ? 'bg-red-500' :
                'bg-slate-300'
              }`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
              <span>{macro.commands.length} commands</span>
              {macro.lastRun && (
                <span>Last run: {macro.lastRun.toLocaleDateString()}</span>
              )}
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => onRun(macro.id)}
                disabled={macro.status === 'running'}
                className="flex-1"
              >
                <Play className="w-4 h-4 mr-1" />
                Run
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onEdit(macro.id)}
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onDelete(macro.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}