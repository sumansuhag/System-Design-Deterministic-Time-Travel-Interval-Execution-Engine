import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { CheckCircle2, Clock, AlertCircle, Circle } from 'lucide-react';
import { MigrationStep } from '../types';

interface MigrationChecklistProps {
  steps: MigrationStep[];
  onStepAction: (id: string) => void;
}

export function MigrationChecklist({ steps, onStepAction }: MigrationChecklistProps) {
  const getIcon = (status: MigrationStep['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'in-progress': return <Clock className="w-5 h-5 text-blue-500 animate-pulse" />;
      case 'error': return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'pending': return <Circle className="w-5 h-5 text-slate-300" />;
    }
  };

  const getStatusBadge = (status: MigrationStep['status']) => {
    const variants = {
      completed: 'bg-green-100 text-green-700 hover:bg-green-100',
      'in-progress': 'bg-blue-100 text-blue-700 hover:bg-blue-100',
      error: 'bg-red-100 text-red-700 hover:bg-red-100',
      pending: 'bg-slate-100 text-slate-700 hover:bg-slate-100'
    };
    return (
      <Badge className={variants[status]} variant="secondary">
        {status.replace('-', ' ')}
      </Badge>
    );
  };

  const groupedSteps = {
    'pre-upgrade': steps.filter(s => s.category === 'pre-upgrade'),
    'os-upgrade': steps.filter(s => s.category === 'os-upgrade'),
    'db-upgrade': steps.filter(s => s.category === 'db-upgrade'),
    'verification': steps.filter(s => s.category === 'verification')
  };

  const categoryTitles = {
    'pre-upgrade': 'Pre-Upgrade Tasks',
    'os-upgrade': 'Operating System',
    'db-upgrade': 'Database Upgrade',
    'verification': 'Post-Upgrade Verification'
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Migration Checklist</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {(Object.keys(groupedSteps) as Array<keyof typeof groupedSteps>).map((category) => (
          <div key={category}>
            <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">
              {categoryTitles[category]}
            </h3>
            <div className="space-y-3">
              {groupedSteps[category].map((step) => (
                <div 
                  key={step.id} 
                  className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                    step.status === 'error' ? 'bg-red-50 border-red-200' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="mt-0.5">{getIcon(step.status)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h4 className="font-medium text-slate-800">{step.title}</h4>
                      {getStatusBadge(step.status)}
                    </div>
                    <p className="text-sm text-slate-500">{step.description}</p>
                  </div>
                  {step.status === 'error' && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => onStepAction(step.id)}
                      className="shrink-0 text-red-600 border-red-200 hover:bg-red-50"
                    >
                      Retry
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}