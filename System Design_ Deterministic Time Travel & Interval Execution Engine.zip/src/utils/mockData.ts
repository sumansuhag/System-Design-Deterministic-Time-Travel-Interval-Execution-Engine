import { Environment, QueryPlan } from '../types';

export const environments: Environment[] = [
  {
    name: 'PROD',
    type: 'production',
    rowCount: 2300000000, // 2.3B
    rtsStatus: 'current',
    lastUpdated: new Date(Date.now() - 1000 * 60 * 15), // 15 mins ago
  },
  {
    name: 'NON-PROD',
    type: 'non-production',
    rowCount: 50000,
    rtsStatus: 'stale',
    lastUpdated: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7), // 7 days ago
  }
];

export const prodPlan: QueryPlan[] = [
  {
    operation: 'TABLE SCAN',
    cost: 4500,
    cardinality: 2300000000,
    filter: 'WHERE status <> \'ACTIVE\''
  }
];

export const nonProdPlan: QueryPlan[] = [
  {
    operation: 'INDEX SCAN',
    cost: 12,
    cardinality: 50000,
    filter: 'WHERE status <> \'ACTIVE\''
  }
];

export const simulatedPlan: QueryPlan[] = [
  {
    operation: 'INDEX SCAN',
    cost: 420,
    cardinality: 2300000000,
    filter: 'WHERE status <> \'ACTIVE\''
  }
];