export function generateId() {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

export function createEmptyMacro() {
  return {
    id: generateId(),
    name: 'New Macro',
    description: '',
    commands: [],
    createdAt: new Date(),
    status: 'idle',
  };
}

export function createCommand(type) {
  return {
    id: generateId(),
    type,
    value: '',
    duration: type === 'delay' ? 1000 : undefined,
  };
}

export function formatDuration(ms) {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

export function getCommandIcon(type) {
  switch (type) {
    case 'text': return '📝';
    case 'delay': return '⏱️';
    case 'click': return '👆';
    case 'keypress': return '⌨️';
    default: return '❓';
  }
}