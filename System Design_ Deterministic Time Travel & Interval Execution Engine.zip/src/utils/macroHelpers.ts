import { v4 as uuidv4 } from 'uuid';

export const createEmptyMacro = () => ({
  id: uuidv4(),
  name: 'New Macro',
  description: '',
  commands: [],
  createdAt: new Date(),
  status: 'idle' as const,
});

export const createCommand = (type: 'text' | 'delay' | 'click' | 'keypress') => ({
  id: uuidv4(),
  type,
  value: '',
  duration: type === 'delay' ? 1000 : undefined,
});

export const formatDuration = (ms: number) => {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
};

export const getCommandIcon = (type: string) => {
  switch (type) {
    case 'text': return '📝';
    case 'delay': return '⏱️';
    case 'click': return '👆';
    case 'keypress': return '⌨️';
    default: return '❓';
  }
};