export interface MacroCommand {
  id: string;
  type: 'text' | 'delay' | 'click' | 'keypress';
  value: string;
  duration?: number;
}

export interface Macro {
  id: string;
  name: string;
  description: string;
  commands: MacroCommand[];
  createdAt: Date;
  lastRun?: Date;
  status: 'idle' | 'running' | 'completed' | 'error';
}

export type MacroStatus = Macro['status'];