export interface Environment {
  name: string;
  type: 'production' | 'non-production';
  rowCount: number;
  rtsStatus: 'current' | 'stale' | 'missing';
  lastUpdated: Date;
}

export interface QueryPlan {
  operation: 'TABLE SCAN' | 'INDEX SCAN' | 'FETCH';
  cost: number;
  cardinality: number;
  filter?: string;
}

export interface IndexProposal {
  columns: string[];
  includedColumns: string[];
  estimatedCostReduction: number;
  status: 'proposed' | 'simulated';
}